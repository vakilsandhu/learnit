-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2018 at 01:32 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_homeworks`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`username`, `password`) VALUES
('admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `comment` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `comment`) VALUES
(1, 'sukhdip', 'sukhdip@gmail.com', 'what should i do to do?');

-- --------------------------------------------------------

--
-- Table structure for table `profiletable`
--

CREATE TABLE IF NOT EXISTS `profiletable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `pic` varchar(20) NOT NULL,
  `experience` varchar(10) NOT NULL,
  `speciality` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `profiletable`
--

INSERT INTO `profiletable` (`id`, `name`, `phone`, `city`, `type`, `pic`, `experience`, `speciality`) VALUES
(1, 'albert', '37773773', 'amritsar', 'Architecture', 'albert.jpg', '2 years', 'best in interrior and xterior design.'),
(2, 'adam', '453335555', 'georgia', 'Electirtion', 'adam.jpg', '4 years', 'best in PLC SACAD and other automations works'),
(3, 'john', '37773773', 'Moga', 'Mason', 'john.jpg', '2 years', 'he is a very hard worker.'),
(4, 'johny', '453533', 'vancover', 'Gardner', 'johny.jpg', '3 year', 'good designer'),
(5, 'Frank', '4346343', 'calefornia', 'lumber', '', '', ''),
(6, 'Frank', '37773773', 'calefornia', '', '', '', ''),
(7, 'Frank', '37773773', 'calefornia', 'Plumber', 'frank.jpg', '3 year', 'good worker'),
(8, 'Vakil Singh', '08221960069', 'SIRSA', 'Driver', 'B612_20171117_105410', '2year', 'good worker'),
(9, 'Vakil Singh', '08221960069', 'SIRSA', 'Plumber', '', '', ''),
(10, 'Vakil Singh', '08221960069', 'SIRSA', 'Select', 'B612_20171115_144802', '', ''),
(11, 'vakil sandhu', '8221960069', '', 'Plumber', 'BeautyPlus_201705101', '2year', '');
